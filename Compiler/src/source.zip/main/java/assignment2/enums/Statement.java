package assignment2;

public enum Statement {
    NULL,
    RETURN,
    BREAK,
    LOOP,
    CONDITIONAL,
    ASSIGN,
}
