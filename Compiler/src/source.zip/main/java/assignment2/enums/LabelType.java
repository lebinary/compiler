package assignment2;

public enum LabelType {
    DEFAULT,
    RETURN,
    BREAK,
}
