package assignment2;

public enum BinopType {
    ARITHMETIC,
    BITWISE,
    COMPARISON,
}
